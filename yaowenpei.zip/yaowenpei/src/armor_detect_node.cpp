#include <string>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <cv_bridge/cv_bridge.hpp>
#include <opencv2/opencv.hpp>
#include "/home/yaoduoduo/my_rm_ws/src/my_vision_pkg/include/armor.hpp"

#include <vector>
#include <chrono>

using namespace std;
using namespace cv;
using namespace auto_aim;

class ArmorDetectNode : public rclcpp::Node
{
public:
    ArmorDetectNode() : Node("armor_detect_node")
    {
        this->declare_parameter<string>("video_path", "/home/yaoduoduo/8.4second_clip_194.800_204.avi");
        string video_path = this->get_parameter("video_path").as_string();

        cap_.open(video_path);
        if (!cap_.isOpened()) {
            RCLCPP_ERROR(this->get_logger(), "无法打开视频文件: %s", video_path.c_str());
            return;
        }

        timer_ = this->create_wall_timer(
            chrono::milliseconds(10),
            bind(&ArmorDetectNode::process_frame, this));

        pub_ = this->create_publisher<sensor_msgs::msg::Image>("/camera/armor_result", 10);

        armor_width_ = 135e-3;
        armor_height_ = 56e-3;

        FileStorage fs("/home/yaoduoduo/my_calibration.yaml", FileStorage::READ);
        if (fs.isOpened()) {
            fs["camera_matrix"] >> camera_matrix_;
            fs["distortion_coefficients"] >> dist_coeffs_;
            RCLCPP_INFO(this->get_logger(), "已加载相机内参");
        }

        object_points_ = {
            Point3f(0,armor_width_ / 2, armor_height_ / 2 ),
            Point3f(0,-armor_width_ / 2, armor_height_ / 2 ),
            Point3f(0,-armor_width_ / 2, -armor_height_ / 2 ),
            Point3f(0,armor_width_ / 2, -armor_height_ / 2 )
        };

        RCLCPP_INFO(this->get_logger(), "装甲板识别节点已启动");
    }

private:
    vector<Armor> find_armors(Mat & frame, const Mat & mask, Scalar box_color)
    {
        vector<vector<Point>> contours;
        findContours(mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        vector<Lightbar> lightbars;
        int frame_h = frame.rows;

            for (auto & c : contours) {
            float contour_area = contourArea(c);
            if (contour_area < 30) continue; 

            RotatedRect rect = minAreaRect(c);
            
            Lightbar lb(rect, lightbars.size(), contour_area);

            if (lb.ratio > 3.0 && lb.ratio < 15.0 
                && lb.fill_ratio > 0.8 
                && lb.length > 10 
                && lb.length < frame_h * 0.25
                && lb.angle > CV_PI / 4 && lb.angle < 3 * CV_PI / 4) 
            {
                lightbars.push_back(lb);
                light_bar_count++;
            }
        }

        vector<Armor> armors;
        for (size_t i = 0; i < lightbars.size(); i++) {
            for (size_t j = i + 1; j < lightbars.size(); j++) {
                Armor armor(lightbars[i], lightbars[j]);

                                
                if (armor.side_ratio < 1.3 &&
                    armor.ratio > 1.5 && armor.ratio < 5.0 &&
                    armor.rectangular_error < 0.3 &&
                    armor.armor_angle < 35.0f) 
                {
                    
                    Point2f pts[4];
                    armor.left.rotated_rect.points(pts);
                    for (int k = 0; k < 4; k++)
                        line(frame, pts[k], pts[(k + 1) % 4], box_color, 2);
                    armor.right.rotated_rect.points(pts);
                    for (int k = 0; k < 4; k++)
                        line(frame, pts[k], pts[(k + 1) % 4], box_color, 2);

                    
                    circle(frame, armor.center, 5, Scalar(0, 255, 255), -1);

                    
                    for (int k = 0; k < 4; k++)
                        line(frame, armor.points[k], armor.points[(k + 1) % 4], box_color, 2);

                    armors.push_back(armor);
                }
            }
        }
        return armors;
    }

            void process_frame()
    {
        auto start = chrono::high_resolution_clock::now();

        Mat frame;
        if (!cap_.read(frame)) {
            RCLCPP_INFO(this->get_logger(), "视频播放完毕，按任意键退出...");
            rclcpp::shutdown();
            return;
        }

        Mat hsv;
        cvtColor(frame, hsv, COLOR_BGR2HSV);

        Mat mask_red1, mask_red2, mask_red, mask_red_white;
        inRange(hsv, Scalar(0, 80, 80), Scalar(12, 255, 255), mask_red1);
        inRange(hsv, Scalar(168, 80, 80), Scalar(180, 255, 255), mask_red2);
        inRange(hsv, Scalar(0, 0, 180), Scalar(180, 50, 255), mask_red_white);
        mask_red = mask_red1 | mask_red2 | mask_red_white;

        Mat mask_blue, mask_blue_white;
        inRange(hsv, Scalar(100, 100, 100), Scalar(140, 255, 255), mask_blue);
        inRange(hsv, Scalar(0, 0, 180), Scalar(180, 50, 255), mask_blue_white);
        mask_blue = mask_blue | mask_blue_white;

        Mat kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
        morphologyEx(mask_red, mask_red, MORPH_OPEN, kernel);
        morphologyEx(mask_red, mask_red, MORPH_CLOSE, kernel);
        morphologyEx(mask_blue, mask_blue, MORPH_OPEN, kernel);
        morphologyEx(mask_blue, mask_blue, MORPH_CLOSE, kernel);

        vector<Armor> enemy_armors = find_armors(frame, mask_red, Scalar(0, 255, 0));
        vector<Armor> ally_armors = find_armors(frame, mask_blue, Scalar(255, 255, 0));

        
        float show_dist = 0.0f, show_ax = 0.0f, show_ay = 0.0f;
        if (!enemy_armors.empty() && !camera_matrix_.empty()) {
            auto & a = enemy_armors[0];
            
            Point2f top_left = a.left.center.y < a.right.center.y ? a.left.top : a.left.bottom;
            Point2f bottom_left = a.left.center.y < a.right.center.y ? a.left.bottom : a.left.top;
            Point2f bottom_right = a.right.center.y < a.left.center.y ? a.right.bottom : a.right.top;
            Point2f top_right = a.right.center.y < a.left.center.y ? a.right.top : a.right.bottom;

            vector<Point2f> pnp_points = {top_left, bottom_left,  bottom_right,top_right };
            
            Mat rvec, tvec;
            if (solvePnP(object_points_, pnp_points, camera_matrix_, dist_coeffs_, rvec, tvec)) {
                show_dist = norm(tvec) * 100.0f;
                
            }
        }

        auto end = chrono::high_resolution_clock::now();
        double ms = chrono::duration<double, milli>(end - start).count();
        

        int y = 40; 
        char info[128];
        
        snprintf(info, sizeof(info), "延迟=%.0f", ms); 
        putText(frame, info, Point(10, y), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 255, 0), 2); y += 35;

        snprintf(info, sizeof(info), "dist=%.6f", show_dist);
        putText(frame, info, Point(10, y), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 255, 0), 2); y += 35;


        snprintf(info, sizeof(info), "num=%d", light_bar_count);
        putText(frame, info, Point(10, y), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 255, 0), 2); y += 35;


        imshow("Frame", frame);
        waitKey(1);

        cv_bridge::CvImage out_msg;
        out_msg.header.stamp = this->now();
        out_msg.encoding = sensor_msgs::image_encodings::BGR8;
        out_msg.image = frame;
        pub_->publish(*out_msg.toImageMsg());
    }

    VideoCapture cap_;
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr pub_;

    Mat camera_matrix_, dist_coeffs_;
    double armor_width_, armor_height_;
    vector<Point3f> object_points_;
     int light_bar_count = 0;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(make_shared<ArmorDetectNode>());
    rclcpp::shutdown();
    return 0;
}
