#include "/home/yaoduoduo/my_rm_ws/src/my_vision_pkg/include/armor.hpp"
#include <algorithm>
#include <cmath>

using namespace cv;
using namespace std;

namespace auto_aim
{

Lightbar::Lightbar(const RotatedRect & rotated_rect, size_t id,float contour_area)
: id(id), rotated_rect(rotated_rect)
{
    vector<Point2f> corners(4);
    rotated_rect.points(&corners[0]);
    sort(corners.begin(), corners.end(), [](const Point2f & a, const Point2f & b) {
        return a.y < b.y;
    });

    center = rotated_rect.center;
    top = (corners[0] + corners[1]) / 2;
    bottom = (corners[2] + corners[3]) / 2;
    top2bottom = bottom - top;

    points.emplace_back(top);
    points.emplace_back(bottom);

    width = norm(corners[0] - corners[1]);
    angle = atan2(top2bottom.y, top2bottom.x);
    angle_error = abs(angle - CV_PI / 2);
    length = norm(top2bottom);
    ratio = length / width;
    
    float rect_area = rotated_rect.size.width * rotated_rect.size.height;
    fill_ratio = (rect_area > 0) ? (contour_area / rect_area) : 0.0f;
}

Armor::Armor(const Lightbar & left, const Lightbar & right)
: left(left), right(right), duplicated(false)
{
    center = (left.center + right.center) / 2;

    points.emplace_back(left.top);
    points.emplace_back(right.top);
    points.emplace_back(right.bottom);
    points.emplace_back(left.bottom);

    auto left2right = right.center - left.center;
    auto width = norm(left2right);
    auto max_lightbar_length = max(left.length, right.length);
    auto min_lightbar_length = min(left.length, right.length);
    ratio = width / max_lightbar_length;
    side_ratio = max_lightbar_length / min_lightbar_length;

    auto roll = atan2(left2right.y, left2right.x);
    auto left_rectangular_error = abs(left.angle - roll - CV_PI / 2);
    auto right_rectangular_error = abs(right.angle - roll - CV_PI / 2);
    rectangular_error = max(left_rectangular_error, right_rectangular_error);
    armor_angle = abs(roll) / CV_PI * 180.0f;
    if (armor_angle > 90.0f) {
        armor_angle = 180.0f - armor_angle;
    }
}

}  
