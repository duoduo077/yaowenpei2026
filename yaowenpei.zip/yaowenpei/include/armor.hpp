#ifndef ARMOR_HPP
#define ARMOR_HPP

#include <opencv2/opencv.hpp>
#include <vector>
#include <string>

using namespace cv;
using namespace std;

namespace auto_aim
{

struct Lightbar
{
    int id;
    RotatedRect rotated_rect;
    Point2f center;
    Point2f top;
    Point2f bottom;
    Point2f top2bottom;
    vector<Point2f> points;
    float width;
    float angle;
    float angle_error;
    float length;
    float ratio;
    float fill_ratio;

    Lightbar(const RotatedRect & rotated_rect, size_t id , float contour_area);
};

struct Armor
{
    Lightbar left;
    Lightbar right;
    bool duplicated;

    Point2f center;
    vector<Point2f> points;
    float ratio;
    float side_ratio;
    float rectangular_error;
    float armor_angle;

    
    Armor(const Lightbar & left, const Lightbar & right);
};

}  

#endif  
